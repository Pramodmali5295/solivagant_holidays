# Solivagant Holidays

Welcome to the official repository for **Solivagant Holidays**, your trusted travel partner for unforgettable journeys across the globe.

## 🌟 About the Project

This is a modern, responsive, and high-performance travel agency landing page designed to showcase tour lists, destinations, and provide a seamless enquiry process for travelers.

### Key Features

- **Modern Design**: Built with a "premium" aesthetic, utilizing the Playfair Display and DM Sans fonts.
- **GSAP Animations**: Smooth, high-end transitions and entrance animations for a lively user experience.
- **Fully Responsive**: Optimized for desktop, tablet, and mobile devices.
- **Performance Optimized**: Implements lazy-loading (code splitting) for lightning-fast initial load times.
- **Seamless Enquiry Form**: Integrated with Web3Forms for direct email inquiries without a backend.
- **Floating Socials**: Sticky social media quick-access menu (WhatsApp, Instagram, Facebook).

## 🚀 Technologies Used

- **Frontend**: React 18, Vite, TypeScript
- **Styling**: Tailwind CSS, shadcn/ui
- **Animation**: GSAP (GreenSock Animation Platform)
- **Icons**: Lucide React
- **Form Handling**: Web3Forms

## 🛠️ Local Development

### Prerequisites

- Node.js & npm installed.

### Setup Instructions

1. **Clone the repository**:
   ```sh
   git clone <YOUR_GIT_URL>
   cd solivagant-holidays
   ```
2. **Install dependencies**:
   ```sh
   npm install
   ```
3. **Run the development server**:
   ```sh
   npm run dev
   ```
4. **Build for production**:
   ```sh
   npm run build
   ```

## 📩 Contact Us

For any travel inquiries or support:

- **Phone**: +91 98765 43210
- **Email**: info@solivagantholidays.com
- **Website**: [solivagantholidays.com](https://solivagantholidays.com)

© 2026 Solivagant Holidays. All rights reserved.
